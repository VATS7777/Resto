const explorebtn = document.getElementById('expbtn')

explorebtn.addEventListener('click', () => {
		window.open("index1.html","_self")
});